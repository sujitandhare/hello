package org.flight.booking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/bookingInformation")
public class bookingServlet extends HttpServlet {

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String TICKET=req.getParameter("TICKET_NO");
		String NAME=req.getParameter("NAME");
		String AGE1=req.getParameter("AGE");
		String GENDER=req.getParameter("GENDER");
		String PHONENO1=req.getParameter("PHONENO");
		String F_ROM=req.getParameter("F_ROM");
		String T_O=req.getParameter("T_O");
		String DEPART=req.getParameter("DEPART");
		String R_ETURN=req.getParameter("R_ETURN");
		String CLASS=req.getParameter("CLASS");
		
		int TICKET_NO=Integer.parseInt(TICKET);
		int AGE=Integer.parseInt(AGE1);
		int PHONENO=Integer.parseInt(PHONENO1);
		
		PrintWriter out=resp.getWriter();
		
		try {
			int result=booking_JDBC.save(TICKET_NO,NAME,AGE,GENDER,PHONENO,F_ROM,T_O,DEPART,R_ETURN,CLASS);
			
			if (result==1) {
				out.println("<h2>Bookig is Confrimed2</h2>");		
				RequestDispatcher rd=req.getRequestDispatcher("bookingTicket.html");
				rd.forward(req, resp);
			}else {
				out.println("<h2>Bookig is Not Confrimed2</h2>");
				RequestDispatcher rd=req.getRequestDispatcher("bookingTicket.html");
				rd.include(req, resp);
			}
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
