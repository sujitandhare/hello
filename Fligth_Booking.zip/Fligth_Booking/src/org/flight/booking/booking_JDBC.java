package org.flight.booking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class booking_JDBC {
	
	static String sqlInsert="insert into ticket_booking values(?,?,?,?,?,?,?,?,?,?)";
	static String url="jdbc:oracle:thin:@localhost:1521:ORCL";
	static String usrName="scott";
	static String password="tiger";
	
	public static int save(int tICKET_NO, String nAME, int aGE, String gENDER, int pHONENO, String f_ROM, String t_O, String dEPART, String r_ETURN, String cLASS) throws ClassNotFoundException, SQLException {
		int count=0;
		// loadig the driver class
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Connection
			Connection con=DriverManager.getConnection(url,usrName,password);
			
			if (con!=null) {
				PreparedStatement ps=con.prepareStatement(sqlInsert);
				if (ps!=null) {
					
					ps.setInt(1, tICKET_NO);
					ps.setString(2, nAME);
					ps.setInt(3, aGE);
					ps.setString(4, gENDER);
					ps.setInt(5, pHONENO);
					ps.setString(6, f_ROM);
					ps.setString(7, t_O);
					ps.setString(8, dEPART);
					ps.setString(9, r_ETURN);
					ps.setString(10, cLASS);
					
					count=ps.executeUpdate();
				}
			}	
		return count;

	}
}