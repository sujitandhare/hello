package org.flight.cancleBooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class cancleBooking_JDBC {

	static String sqlDelete="delete ticket_booking where TICKET_NO=?";
	static String url="jdbc:oracle:thin:@localhost:1521:ORCL";
	static String usrName="scott";
	static String password="tiger";
	
	public static int delete(int TICKET_NO) throws SQLException {
		
		int count=0;
				try {	
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				 

				// Connection
				Connection con=DriverManager.getConnection(url,usrName,password);
				
			
					PreparedStatement ps=con.prepareStatement(sqlDelete);
					
						
						ps.setInt(1 , TICKET_NO);
						
						count=ps.executeUpdate();
						
					
			} catch (Exception e) {
				e.printStackTrace();
			}
			return count;	
		}


}
