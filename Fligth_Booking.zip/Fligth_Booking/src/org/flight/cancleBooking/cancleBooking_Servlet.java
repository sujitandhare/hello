package org.flight.cancleBooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cancle_TICKET_NO")
public class cancleBooking_Servlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String TICKET=req.getParameter("TICKET_NO");
		
		int TICKET_NO=Integer.parseInt(TICKET);
		PrintWriter out=resp.getWriter();
		try {
			int result=cancleBooking_JDBC.delete(TICKET_NO);
			
			if (result==1) {
				
				RequestDispatcher rd=req.getRequestDispatcher("/indexPage.html");
				rd.forward(req, resp);
			}else {
				out.println("<h2>TICKET_NO Is Not Booing Please Enter Other Number</h2>");
				RequestDispatcher rd=req.getRequestDispatcher("/cancleBooking.html");
				rd.include(req, resp);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
