package org.flight.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class Login_JDBC {
	
	static String sqlCheck="select * from login_tab where USERNAME=? and PASSWORD=?";
	static String url="jdbc:oracle:thin:@localhost:1521:ORCL";
	static String usrName="scott";
	static String password="tiger";
	
public static boolean isExixt(String un, String pwd) throws SQLException {
		
		boolean flag=false;

		try {	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 

			// Connection
			Connection con=DriverManager.getConnection(url,usrName,password);
			
		
				PreparedStatement ps=con.prepareStatement(sqlCheck);
				
					
					ps.setString(1 , un);
					ps.setString(2 , pwd);
						
					ResultSet rs=ps.executeQuery();
					if (rs.next()) {
						flag=true;
					}else {
						flag=false;
					}
				
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}

	
}
