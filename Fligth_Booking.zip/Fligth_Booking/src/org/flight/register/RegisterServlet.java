package org.flight.register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		String eid=req.getParameter("id");
		String un=req.getParameter("un");
		String pwd=req.getParameter("pwd");
		
		int id=Integer.parseInt(eid);		
		try {
			int count=Register_JDBC.save(id, un, pwd);
			if (count==1) {
				
				RequestDispatcher rd=req.getRequestDispatcher("homePage.html");
				rd.forward(req, resp);
			}else {
				
				RequestDispatcher rd=req.getRequestDispatcher("registerPage.html");
				rd.include(req, resp);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}	
	}
}
