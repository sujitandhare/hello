package org.flight.register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Register_JDBC {
	
	static String sqlInsert="insert into login_tab values(?,?,?)";
	static String url="jdbc:oracle:thin:@localhost:1521:ORCL";
	static String usrName="scott";
	static String password="tiger";
	
	public static int save( int id, String un, String pwd) throws ClassNotFoundException, SQLException {
		int count=0;
		// loadig the driver class
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Connection
			Connection con=DriverManager.getConnection(url,usrName,password);
			
			if (con!=null) {
				PreparedStatement ps=con.prepareStatement(sqlInsert);
				if (ps!=null) {
					ps.setInt(1, id);
					ps.setString(2, un);;
					ps.setString(3, pwd);
					
					count=ps.executeUpdate();
				}
			}	
		return count;
	}
	

}